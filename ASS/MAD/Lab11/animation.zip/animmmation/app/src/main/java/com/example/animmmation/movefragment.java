package com.example.animmmation;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;


public class movefragment extends Fragment implements Animation.AnimationListener {
    ImageView imageView;
    Button btnmove;
    View view;
    Animation animMove;




    public static movefragment newInstance(String param1, String param2) {
        movefragment fragment = new movefragment();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @SuppressLint("ResourceType")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_movefragment, container, false);
        imageView = (ImageView) view.findViewById(R.id.imgmove);
        btnmove = (Button)view.findViewById(R.id.btnmove);
        animMove = AnimationUtils.loadAnimation(getContext(),
                R.anim.move );
        animMove.setAnimationListener(this);
        btnmove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageView.startAnimation(animMove);
            }
        });
        return view;
    }

    @Override
    public void onAnimationStart(Animation animation) {

    }

    @Override
    public void onAnimationEnd(Animation animation) {

    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }
}