package com.example.animmmation;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;


public class blinkfragment extends Fragment implements Animation.AnimationListener {

    ImageView imageView;
    Button btnStart;
    View view;
    Animation animBlink;



    public static blinkfragment newInstance(String param1, String param2) {
        blinkfragment fragment = new blinkfragment();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    public blinkfragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @SuppressLint("ResourceType")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_blinkfragment, container, false);
        imageView = (ImageView) view.findViewById(R.id.imageblink);
        btnStart = (Button)view.findViewById(R.id.btnStart);
        animBlink = AnimationUtils.loadAnimation(getContext(),R.anim.bink);
        animBlink.setAnimationListener(this);
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageView.setVisibility(View.VISIBLE);
                imageView.startAnimation(animBlink);
            }
        });
        return view;
    }

    @Override
    public void onAnimationStart(Animation animation) {

    }

    @Override
    public void onAnimationEnd(Animation animation) {

    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }
}