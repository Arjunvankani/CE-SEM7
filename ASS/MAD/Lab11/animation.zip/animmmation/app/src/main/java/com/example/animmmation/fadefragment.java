package com.example.animmmation;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link fadefragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class fadefragment extends Fragment  implements Animation.AnimationListener {

    ImageView imageView;
    Button btnstart;
    View view;
    Animation animFade;


    public fadefragment() {
        // Required empty public constructor
    }


    public static fadefragment newInstance(String param1, String param2) {
        fadefragment fragment = new fadefragment();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @SuppressLint("ResourceType")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_fadefragment, container, false);
        imageView = (ImageView) view.findViewById(R.id.imgfade);
        btnstart = (Button)view.findViewById(R.id.btnfade);
        animFade = AnimationUtils.loadAnimation(getContext(),
                R.anim.fade );
        animFade.setAnimationListener(this);
        btnstart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageView.startAnimation(animFade);
            }
        });
        return view;
    }

    @Override
    public void onAnimationStart(Animation animation) {

    }

    @Override
    public void onAnimationEnd(Animation animation) {

    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }
}