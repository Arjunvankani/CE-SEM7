package com.example.animmmation;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link sequentialanimationfragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class sequentialanimationfragment extends Fragment implements Animation.AnimationListener {

    ImageView imageView;
    Button btnStart;
    View view;
    Animation animSequence;

    public sequentialanimationfragment() {

    }


    public static sequentialanimationfragment newInstance(String param1, String param2) {
        sequentialanimationfragment fragment = new sequentialanimationfragment();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_sequentialanimationfragment, container, false);
        imageView = (ImageView) view.findViewById(R.id.imgsequence);
        btnStart = (Button)view.findViewById(R.id.btnSequence);
        animSequence = AnimationUtils.loadAnimation(getContext(),
                R.anim.sequential );
        animSequence.setAnimationListener(this);

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                imageView.startAnimation(animSequence);
            }
        });
        return view;
    }

    @Override
    public void onAnimationStart(Animation animation) {

    }

    @Override
    public void onAnimationEnd(Animation animation) {

    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }
}